import java.util.*;

public class Program2 {

    public int constructIntensityGraph(int[][] image){
		//TODO: Create this method
    }

    public int constructPrunedGraph(int[][] image){
		//TODO: Create this method
    }
}